Arduino---MATLAB---Serial-Port-Communication
============================================

Códigos de Arduino y MATLAB para comunicación puerto serie.

Para descargar:

~~~
git clone https://github.com/GeekyTheory/Arduino---MATLAB---Serial-Port-Communication.git
~~~

Para más información, visitar: [Geeky Theory Tutorial](http://www.geekytheory.com/matlab-arduino-serial-port-communication/ "")