LabVIEW Interface for Arduino     
                                            
The LabVIEW Interface for Arduino (LIFA) Toolkit is a FREE download that allows developers to acquire data from the Arduino microcontroller and process it in the LabVIEW Graphical Programming environment. You can purchase the Arduino Uno bundled with a LabVIEW Student Edition DVD from Sparkfun Electronics.
